package br.com.diego.passaportecafeterias;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String PREFS = "rotas_cafeterias_prefs";
    private static final String PROGRESS_KEY = "visit_progress_v2";

    public class AndroidStorageBridge {
        @JavascriptInterface
        public String loadProgress() {
            return getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(PROGRESS_KEY, "");
        }

        @JavascriptInterface
        public void saveProgress(String json) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(PROGRESS_KEY, json).apply();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 46, 29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 46, 29));
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        webView.addJavascriptInterface(new AndroidStorageBridge(), "AndroidStorage");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
